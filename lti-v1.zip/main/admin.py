from django.contrib import admin
from .models import *
admin.site.register(Business_Registration)
admin.site.register(Registration_Licencing)
admin.site.register(Gst_IncomeTax)
admin.site.register(Intellectual_Property)
admin.site.register(Information_Technology)
admin.site.register(Other_Service)
admin.site.register(Documents)
admin.site.register(Contactus)